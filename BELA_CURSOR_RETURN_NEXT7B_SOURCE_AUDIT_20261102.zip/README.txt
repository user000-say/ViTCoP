READ ONLY source audit collection. Check this archive for secrets before transferring. Missing paths are listed in meta/manifest.json.
